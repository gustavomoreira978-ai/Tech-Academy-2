-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 31-Maio-2026 às 00:48
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `loja`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `camisetas`
--

CREATE TABLE `camisetas` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `categoria` varchar(50) NOT NULL,
  `imagem2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `camisetas`
--

INSERT INTO `camisetas` (`id`, `nome`, `descricao`, `preco`, `imagem`, `categoria_id`, `categoria`, `imagem2`) VALUES
(1, 'Camiseta Naruto', 'Estampa Naruto', 59.90, 'naruto.jpg', 1, 'Camiseta', 'naruto costas.jpg'),
(2, 'Camiseta One Piece', 'Estampa Luffy', 69.90, 'one piece frente.jpg\r\n', 1, 'Camiseta', 'one piece costas.jpg'),
(3, 'Moletom Naruto', 'Moletom Akatsuki Premium', 149.90, 'akatsuki frente.jpg\r\n', NULL, 'Moletom', 'akatsuki costas.jpg'),
(4, 'Moletom One Piece', 'Moletom Luffy Gear 5', 159.90, 'luffy.jpg', NULL, 'Moletom', NULL),
(5, 'Moletom Dragon Ball', 'Moletom Goku Ultra Instinto', 169.90, 'goku costas.jpeg\r\n', NULL, 'Moletom', 'goku frente.jpeg'),
(6, 'Moletom Solo Leveling', 'Moletom Sung Jin-Woo', 179.90, 'sung.png\r\n', NULL, 'Moletom', 'sung costas.png');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `camisetas`
--
ALTER TABLE `camisetas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `camisetas`
--
ALTER TABLE `camisetas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `camisetas`
--
ALTER TABLE `camisetas`
  ADD CONSTRAINT `camisetas_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
